--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 16.3
-- Dumped by pg_dump version 16.3

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE golang;
--
-- Name: golang; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE golang WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'English_India.1252';


ALTER DATABASE golang OWNER TO postgres;

\connect golang

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: acquirer; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.acquirer (
    acquirer_id smallint NOT NULL,
    acquirer_title character varying(200) NOT NULL,
    api_key character varying(200),
    secret_key character varying(200),
    endpoint_url character varying(200),
    callback_url character varying(200),
    success_url character varying(200),
    failed_url character varying(200),
    json_data json,
    status smallint DEFAULT 1 NOT NULL
);


ALTER TABLE public.acquirer OWNER TO postgres;

--
-- Name: acquirer_acquirer_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.acquirer ALTER COLUMN acquirer_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.acquirer_acquirer_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: admin_master; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.admin_master (
    admin_id smallint NOT NULL,
    username character varying(100) DEFAULT NULL::character varying,
    password character varying(100) DEFAULT NULL::character varying,
    full_name character varying(50),
    status smallint DEFAULT 1,
    "timestamp" timestamp with time zone DEFAULT now(),
    role character varying(20)
);


ALTER TABLE public.admin_master OWNER TO postgres;

--
-- Name: admin_master_admin_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.admin_master ALTER COLUMN admin_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.admin_master_admin_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: transaction_master; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.transaction_master (
    id smallint NOT NULL,
    transaction_id character varying(100) NOT NULL,
    client_id smallint NOT NULL,
    volt_id character varying(20) NOT NULL,
    assetid character varying(50) NOT NULL,
    transaction_type character varying(100) DEFAULT now() NOT NULL,
    requestedamount double precision DEFAULT 0.0 NOT NULL,
    amount double precision NOT NULL,
    netamount double precision DEFAULT 0.0 NOT NULL,
    amountusd double precision DEFAULT 0.0 NOT NULL,
    fee double precision DEFAULT 0.0 NOT NULL,
    networkfee double precision DEFAULT 0.0 NOT NULL,
    status character varying(50),
    substatus character varying(200),
    txhash character varying(200),
    operation character varying(100),
    customerrefid character varying(50),
    ip character varying(30),
    source character varying(200),
    destination555 character varying(200),
    note character varying(200),
    createdate timestamp without time zone DEFAULT now() NOT NULL,
    lastupdated timestamp without time zone DEFAULT now() NOT NULL,
    destinationaddress character varying(200),
    createdby character varying(100)
);


ALTER TABLE public.transaction_master OWNER TO postgres;

--
-- Name: c_master_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.transaction_master ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.c_master_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: client_api; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.client_api (
    id smallint NOT NULL,
    client_id smallint NOT NULL,
    apikey character varying(100),
    status smallint DEFAULT 1,
    "timestamp" timestamp with time zone DEFAULT now()
);


ALTER TABLE public.client_api OWNER TO postgres;

--
-- Name: client_api_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.client_api ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.client_api_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: client_details; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.client_details (
    client_id smallint NOT NULL,
    title character varying(5) DEFAULT NULL::character varying,
    gender character varying(1) DEFAULT NULL::character varying,
    birth_date character varying(30) DEFAULT NULL::character varying,
    country_code character varying(5) DEFAULT NULL::character varying,
    mobile character varying(20) DEFAULT NULL::character varying,
    address_line1 character varying(100) DEFAULT NULL::character varying,
    address_line2 character varying(100) DEFAULT NULL::character varying,
    city character varying(50) DEFAULT NULL::character varying,
    state character varying(50) DEFAULT NULL::character varying,
    country character varying(50) DEFAULT NULL::character varying,
    pincode character varying(10) DEFAULT NULL::character varying,
    add_date character varying(30) DEFAULT NULL::character varying,
    json_log_history character varying(22302) DEFAULT NULL::character varying,
    id smallint NOT NULL
);


ALTER TABLE public.client_details OWNER TO postgres;

--
-- Name: client_details_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.client_details ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.client_details_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: client_fees; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.client_fees (
    fee_id smallint NOT NULL,
    min_amount_fee double precision,
    amount_fee_in_percent double precision,
    client_id smallint NOT NULL
);


ALTER TABLE public.client_fees OWNER TO postgres;

--
-- Name: client_fees_fee_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.client_fees ALTER COLUMN fee_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.client_fees_fee_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: client_master; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.client_master (
    client_id smallint NOT NULL,
    username character varying(100) DEFAULT NULL::character varying,
    password character varying(100) DEFAULT NULL::character varying,
    full_name character varying(50),
    status smallint DEFAULT 1,
    "timestamp" timestamp with time zone DEFAULT now(),
    totp_secret character varying(100),
    user_agent character varying(200),
    totp_status smallint DEFAULT 0 NOT NULL
);


ALTER TABLE public.client_master OWNER TO postgres;

--
-- Name: COLUMN client_master.client_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.client_master.client_id IS 'Merchant ID / USER ID / Registration ID';


--
-- Name: client_master_client_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.client_master ALTER COLUMN client_id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.client_master_client_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: client_wallet; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.client_wallet (
    wallet_id smallint NOT NULL,
    client_id smallint,
    crypto_code character varying(10),
    crypto_title character varying(50),
    crypto_network character varying(100),
    crypto_address character varying(200),
    status smallint DEFAULT 1 NOT NULL,
    assetid integer
);


ALTER TABLE public.client_wallet OWNER TO postgres;

--
-- Name: client_wallet_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.client_wallet ALTER COLUMN wallet_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.client_wallet_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: coin_address; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.coin_address (
    address_id smallint NOT NULL,
    coin character varying(10) NOT NULL,
    address character varying(200) NOT NULL,
    status smallint DEFAULT 1 NOT NULL,
    lastupdate timestamp without time zone,
    coin_id smallint NOT NULL,
    token_details json
);


ALTER TABLE public.coin_address OWNER TO postgres;

--
-- Name: coin_address_address_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.coin_address ALTER COLUMN address_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.coin_address_address_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: coin_list; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.coin_list (
    coin_id smallint NOT NULL,
    coin character varying(10),
    icon character varying(200),
    status smallint DEFAULT 1 NOT NULL,
    coin_title character varying(50),
    coin_network character varying(50),
    coin_status_url character varying(200),
    coin_pay_url character varying(50)
);


ALTER TABLE public.coin_list OWNER TO postgres;

--
-- Name: coin_list_coin_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.coin_list ALTER COLUMN coin_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.coin_list_coin_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: crypto_currency; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.crypto_currency (
    crypto_id smallint NOT NULL,
    crypto_code character varying(10),
    crypto_title character varying(50),
    crypto_network character varying(100),
    status smallint DEFAULT 1 NOT NULL,
    crypto_network_short character varying(50)
);


ALTER TABLE public.crypto_currency OWNER TO postgres;

--
-- Name: crypto_currency_crypto_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.crypto_currency ALTER COLUMN crypto_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.crypto_currency_crypto_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: currency; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.currency (
    currency_id smallint NOT NULL,
    currency_name character varying(50),
    currency_code character varying(10),
    currency_territory character varying(100),
    currency_icon_bootstrap character varying(100),
    status smallint DEFAULT 1 NOT NULL
);


ALTER TABLE public.currency OWNER TO postgres;

--
-- Name: currency_currency_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.currency ALTER COLUMN currency_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.currency_currency_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: customer; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.customer (
    customer_id smallint NOT NULL,
    customer_name character varying(100),
    customer_email character varying(100),
    customer_tid character varying(50),
    "timestamp" timestamp without time zone DEFAULT now() NOT NULL,
    client_id smallint
);


ALTER TABLE public.customer OWNER TO postgres;

--
-- Name: customer_customer_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.customer ALTER COLUMN customer_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.customer_customer_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: email_template; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.email_template (
    template_id smallint NOT NULL,
    template_code character varying(50),
    template_subject character varying(200),
    template_desc text,
    status smallint DEFAULT 1 NOT NULL
);


ALTER TABLE public.email_template OWNER TO postgres;

--
-- Name: email_template_template_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.email_template ALTER COLUMN template_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.email_template_template_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: invoice; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.invoice (
    invoice_id smallint NOT NULL,
    client_id smallint NOT NULL,
    name character varying(50),
    email character varying(100),
    description character varying(200),
    requestedamount double precision NOT NULL,
    requestedcurrency character varying(10) NOT NULL,
    status smallint DEFAULT 1 NOT NULL,
    createdate timestamp without time zone DEFAULT now() NOT NULL,
    ip character varying(20) NOT NULL,
    trackid character varying(100),
    product_name character varying(200) DEFAULT 'Pay Request'::character varying,
    invoice_type smallint DEFAULT 1 NOT NULL
);


ALTER TABLE public.invoice OWNER TO postgres;

--
-- Name: invoice_invoice_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.invoice ALTER COLUMN invoice_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.invoice_invoice_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: login_history; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.login_history (
    token_id integer NOT NULL,
    client_id integer,
    login_time timestamp with time zone DEFAULT now(),
    logout_time timestamp with time zone DEFAULT now(),
    login_ip character varying(30),
    login_type smallint DEFAULT 1 NOT NULL
);


ALTER TABLE public.login_history OWNER TO postgres;

--
-- Name: login_history_token_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.login_history ALTER COLUMN token_id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.login_history_token_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: support-ticket; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."support-ticket" (
    ticket_id smallint NOT NULL,
    client_id smallint,
    ticket_subject character varying(200),
    ticket_desc text,
    status smallint DEFAULT 1 NOT NULL,
    "timestamp" timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public."support-ticket" OWNER TO postgres;

--
-- Name: support-ticket_ticket_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public."support-ticket" ALTER COLUMN ticket_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public."support-ticket_ticket_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: transaction; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.transaction (
    id smallint NOT NULL,
    transaction_id character varying(100) NOT NULL,
    client_id smallint NOT NULL,
    assetid integer,
    transaction_type character varying(100) DEFAULT 2 NOT NULL,
    requestedamount double precision DEFAULT 0.0 NOT NULL,
    requestedcurrency character varying(10),
    convertedamount double precision DEFAULT 0.0 NOT NULL,
    convertedcurrency character varying(10) NOT NULL,
    receivedamount double precision DEFAULT 0.0 NOT NULL,
    receivedcurrency character varying(10),
    status character varying(50) NOT NULL,
    substatus smallint DEFAULT 0 NOT NULL,
    customerrefid character varying(50),
    note character varying(200),
    createdate timestamp without time zone DEFAULT now() NOT NULL,
    destinationaddress character varying(200),
    ip character varying(20),
    approved_by character varying(50),
    approver_id smallint,
    approver_comment character varying(200),
    approved_date timestamp without time zone,
    response_hash character varying(200),
    response_from character varying(200),
    response_to character varying(200),
    response_timestamp timestamp without time zone,
    response_json json
);


ALTER TABLE public.transaction OWNER TO postgres;

--
-- Name: transaction_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.transaction ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.transaction_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: transaction_master_nowpayments; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.transaction_master_nowpayments (
    tid smallint NOT NULL,
    payment_id character varying(50),
    payment_status character varying(20),
    pay_address character varying(50),
    price_amount double precision,
    pay_amount double precision,
    amount_received double precision,
    price_currency character varying(10),
    pay_currency character varying(10),
    order_id character varying(50),
    order_description character varying(200),
    client_id smallint,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    ip character varying(20),
    invoice_id character varying(50),
    token_id character varying(50),
    invoice_url character varying(200),
    request_json text
);


ALTER TABLE public.transaction_master_nowpayments OWNER TO postgres;

--
-- Name: transaction_master_nowpayments_tid_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.transaction_master_nowpayments ALTER COLUMN tid ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.transaction_master_nowpayments_tid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: transactions-for deleted; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."transactions-for deleted" (
    transactionid smallint NOT NULL,
    client_id smallint NOT NULL,
    walletid character varying(100),
    transactiontype character varying(20),
    amount character varying(20),
    transaction_hash character varying(100),
    status character varying(10),
    "timestamp" time with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public."transactions-for deleted" OWNER TO postgres;

--
-- Name: transactions_transactionid_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public."transactions-for deleted" ALTER COLUMN transactionid ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.transactions_transactionid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: wallet_list; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.wallet_list (
    wallet_id smallint NOT NULL,
    volt_id smallint NOT NULL,
    coin character varying(50),
    address character varying(200),
    legacyaddress character varying(200),
    tag character varying(50),
    total character varying(20),
    available character varying(20),
    pending character varying(20),
    frozen character varying(20),
    lockedamount character varying(20),
    status character varying(10) DEFAULT 2,
    "timestamp" time with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.wallet_list OWNER TO postgres;

--
-- Name: wallet_list_wallet_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.wallet_list ALTER COLUMN wallet_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.wallet_list_wallet_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Data for Name: acquirer; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.acquirer (acquirer_id, acquirer_title, api_key, secret_key, endpoint_url, callback_url, success_url, failed_url, json_data, status) FROM stdin;
\.
COPY public.acquirer (acquirer_id, acquirer_title, api_key, secret_key, endpoint_url, callback_url, success_url, failed_url, json_data, status) FROM '$$PATH$$/5070.dat';

--
-- Data for Name: admin_master; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.admin_master (admin_id, username, password, full_name, status, "timestamp", role) FROM stdin;
\.
COPY public.admin_master (admin_id, username, password, full_name, status, "timestamp", role) FROM '$$PATH$$/5059.dat';

--
-- Data for Name: client_api; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.client_api (id, client_id, apikey, status, "timestamp") FROM stdin;
\.
COPY public.client_api (id, client_id, apikey, status, "timestamp") FROM '$$PATH$$/5078.dat';

--
-- Data for Name: client_details; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.client_details (client_id, title, gender, birth_date, country_code, mobile, address_line1, address_line2, city, state, country, pincode, add_date, json_log_history, id) FROM stdin;
\.
COPY public.client_details (client_id, title, gender, birth_date, country_code, mobile, address_line1, address_line2, city, state, country, pincode, add_date, json_log_history, id) FROM '$$PATH$$/5043.dat';

--
-- Data for Name: client_fees; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.client_fees (fee_id, min_amount_fee, amount_fee_in_percent, client_id) FROM stdin;
\.
COPY public.client_fees (fee_id, min_amount_fee, amount_fee_in_percent, client_id) FROM '$$PATH$$/5072.dat';

--
-- Data for Name: client_master; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.client_master (client_id, username, password, full_name, status, "timestamp", totp_secret, user_agent, totp_status) FROM stdin;
\.
COPY public.client_master (client_id, username, password, full_name, status, "timestamp", totp_secret, user_agent, totp_status) FROM '$$PATH$$/5039.dat';

--
-- Data for Name: client_wallet; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.client_wallet (wallet_id, client_id, crypto_code, crypto_title, crypto_network, crypto_address, status, assetid) FROM stdin;
\.
COPY public.client_wallet (wallet_id, client_id, crypto_code, crypto_title, crypto_network, crypto_address, status, assetid) FROM '$$PATH$$/5076.dat';

--
-- Data for Name: coin_address; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.coin_address (address_id, coin, address, status, lastupdate, coin_id, token_details) FROM stdin;
\.
COPY public.coin_address (address_id, coin, address, status, lastupdate, coin_id, token_details) FROM '$$PATH$$/5068.dat';

--
-- Data for Name: coin_list; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.coin_list (coin_id, coin, icon, status, coin_title, coin_network, coin_status_url, coin_pay_url) FROM stdin;
\.
COPY public.coin_list (coin_id, coin, icon, status, coin_title, coin_network, coin_status_url, coin_pay_url) FROM '$$PATH$$/5048.dat';

--
-- Data for Name: crypto_currency; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.crypto_currency (crypto_id, crypto_code, crypto_title, crypto_network, status, crypto_network_short) FROM stdin;
\.
COPY public.crypto_currency (crypto_id, crypto_code, crypto_title, crypto_network, status, crypto_network_short) FROM '$$PATH$$/5074.dat';

--
-- Data for Name: currency; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.currency (currency_id, currency_name, currency_code, currency_territory, currency_icon_bootstrap, status) FROM stdin;
\.
COPY public.currency (currency_id, currency_name, currency_code, currency_territory, currency_icon_bootstrap, status) FROM '$$PATH$$/5062.dat';

--
-- Data for Name: customer; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.customer (customer_id, customer_name, customer_email, customer_tid, "timestamp", client_id) FROM stdin;
\.
COPY public.customer (customer_id, customer_name, customer_email, customer_tid, "timestamp", client_id) FROM '$$PATH$$/5080.dat';

--
-- Data for Name: email_template; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.email_template (template_id, template_code, template_subject, template_desc, status) FROM stdin;
\.
COPY public.email_template (template_id, template_code, template_subject, template_desc, status) FROM '$$PATH$$/5052.dat';

--
-- Data for Name: invoice; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.invoice (invoice_id, client_id, name, email, description, requestedamount, requestedcurrency, status, createdate, ip, trackid, product_name, invoice_type) FROM stdin;
\.
COPY public.invoice (invoice_id, client_id, name, email, description, requestedamount, requestedcurrency, status, createdate, ip, trackid, product_name, invoice_type) FROM '$$PATH$$/5058.dat';

--
-- Data for Name: login_history; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.login_history (token_id, client_id, login_time, logout_time, login_ip, login_type) FROM stdin;
\.
COPY public.login_history (token_id, client_id, login_time, logout_time, login_ip, login_type) FROM '$$PATH$$/5041.dat';

--
-- Data for Name: support-ticket; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."support-ticket" (ticket_id, client_id, ticket_subject, ticket_desc, status, "timestamp") FROM stdin;
\.
COPY public."support-ticket" (ticket_id, client_id, ticket_subject, ticket_desc, status, "timestamp") FROM '$$PATH$$/5064.dat';

--
-- Data for Name: transaction; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.transaction (id, transaction_id, client_id, assetid, transaction_type, requestedamount, requestedcurrency, convertedamount, convertedcurrency, receivedamount, receivedcurrency, status, substatus, customerrefid, note, createdate, destinationaddress, ip, approved_by, approver_id, approver_comment, approved_date, response_hash, response_from, response_to, response_timestamp, response_json) FROM stdin;
\.
COPY public.transaction (id, transaction_id, client_id, assetid, transaction_type, requestedamount, requestedcurrency, convertedamount, convertedcurrency, receivedamount, receivedcurrency, status, substatus, customerrefid, note, createdate, destinationaddress, ip, approved_by, approver_id, approver_comment, approved_date, response_hash, response_from, response_to, response_timestamp, response_json) FROM '$$PATH$$/5065.dat';

--
-- Data for Name: transaction_master; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.transaction_master (id, transaction_id, client_id, volt_id, assetid, transaction_type, requestedamount, amount, netamount, amountusd, fee, networkfee, status, substatus, txhash, operation, customerrefid, ip, source, destination555, note, createdate, lastupdated, destinationaddress, createdby) FROM stdin;
\.
COPY public.transaction_master (id, transaction_id, client_id, volt_id, assetid, transaction_type, requestedamount, amount, netamount, amountusd, fee, networkfee, status, substatus, txhash, operation, customerrefid, ip, source, destination555, note, createdate, lastupdated, destinationaddress, createdby) FROM '$$PATH$$/5054.dat';

--
-- Data for Name: transaction_master_nowpayments; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.transaction_master_nowpayments (tid, payment_id, payment_status, pay_address, price_amount, pay_amount, amount_received, price_currency, pay_currency, order_id, order_description, client_id, created_at, updated_at, ip, invoice_id, token_id, invoice_url, request_json) FROM stdin;
\.
COPY public.transaction_master_nowpayments (tid, payment_id, payment_status, pay_address, price_amount, pay_amount, amount_received, price_currency, pay_currency, order_id, order_description, client_id, created_at, updated_at, ip, invoice_id, token_id, invoice_url, request_json) FROM '$$PATH$$/5056.dat';

--
-- Data for Name: transactions-for deleted; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."transactions-for deleted" (transactionid, client_id, walletid, transactiontype, amount, transaction_hash, status, "timestamp") FROM stdin;
\.
COPY public."transactions-for deleted" (transactionid, client_id, walletid, transactiontype, amount, transaction_hash, status, "timestamp") FROM '$$PATH$$/5050.dat';

--
-- Data for Name: wallet_list; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.wallet_list (wallet_id, volt_id, coin, address, legacyaddress, tag, total, available, pending, frozen, lockedamount, status, "timestamp") FROM stdin;
\.
COPY public.wallet_list (wallet_id, volt_id, coin, address, legacyaddress, tag, total, available, pending, frozen, lockedamount, status, "timestamp") FROM '$$PATH$$/5046.dat';

--
-- Name: acquirer_acquirer_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.acquirer_acquirer_seq', 3, true);


--
-- Name: admin_master_admin_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.admin_master_admin_id_seq', 5, true);


--
-- Name: c_master_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.c_master_id_seq', 52, true);


--
-- Name: client_api_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.client_api_id_seq', 9, true);


--
-- Name: client_details_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.client_details_id_seq', 60, true);


--
-- Name: client_fees_fee_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.client_fees_fee_id_seq', 10, true);


--
-- Name: client_master_client_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.client_master_client_id_seq', 189, true);


--
-- Name: client_wallet_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.client_wallet_id_seq', 22, true);


--
-- Name: coin_address_address_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.coin_address_address_id_seq', 34, true);


--
-- Name: coin_list_coin_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.coin_list_coin_id_seq', 32, true);


--
-- Name: crypto_currency_crypto_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.crypto_currency_crypto_id_seq', 54, true);


--
-- Name: currency_currency_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.currency_currency_id_seq', 16, true);


--
-- Name: customer_customer_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.customer_customer_id_seq', 92, true);


--
-- Name: email_template_template_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.email_template_template_id_seq', 9, true);


--
-- Name: invoice_invoice_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.invoice_invoice_id_seq', 145, true);


--
-- Name: login_history_token_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.login_history_token_id_seq', 3875, true);


--
-- Name: support-ticket_ticket_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."support-ticket_ticket_id_seq"', 11, true);


--
-- Name: transaction_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.transaction_id_seq', 649, true);


--
-- Name: transaction_master_nowpayments_tid_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.transaction_master_nowpayments_tid_seq', 39, true);


--
-- Name: transactions_transactionid_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.transactions_transactionid_seq', 29, true);


--
-- Name: wallet_list_wallet_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.wallet_list_wallet_id_seq', 37, true);


--
-- Name: acquirer acquirer_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.acquirer
    ADD CONSTRAINT acquirer_pkey PRIMARY KEY (acquirer_id);


--
-- Name: admin_master admin_master_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.admin_master
    ADD CONSTRAINT admin_master_pkey PRIMARY KEY (admin_id);


--
-- Name: transaction_master c_master_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.transaction_master
    ADD CONSTRAINT c_master_pkey PRIMARY KEY (id);


--
-- Name: client_api client_api_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.client_api
    ADD CONSTRAINT client_api_pkey PRIMARY KEY (id);


--
-- Name: client_details client_details_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.client_details
    ADD CONSTRAINT client_details_pkey PRIMARY KEY (id);


--
-- Name: client_fees client_fees_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.client_fees
    ADD CONSTRAINT client_fees_pkey PRIMARY KEY (fee_id);


--
-- Name: client_master client_master_client_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.client_master
    ADD CONSTRAINT client_master_client_id_key UNIQUE (client_id);


--
-- Name: client_master client_master_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.client_master
    ADD CONSTRAINT client_master_pkey PRIMARY KEY (client_id);


--
-- Name: client_master client_master_username_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.client_master
    ADD CONSTRAINT client_master_username_key UNIQUE (username);


--
-- Name: client_wallet client_wallet_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.client_wallet
    ADD CONSTRAINT client_wallet_pkey PRIMARY KEY (wallet_id);


--
-- Name: coin_address coin_address_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.coin_address
    ADD CONSTRAINT coin_address_pkey PRIMARY KEY (address_id);


--
-- Name: coin_list coin_list_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.coin_list
    ADD CONSTRAINT coin_list_pkey PRIMARY KEY (coin_id);


--
-- Name: client_details constraint_name; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.client_details
    ADD CONSTRAINT constraint_name UNIQUE (client_id);


--
-- Name: crypto_currency crypto_currency_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.crypto_currency
    ADD CONSTRAINT crypto_currency_pkey PRIMARY KEY (crypto_id);


--
-- Name: currency currency_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.currency
    ADD CONSTRAINT currency_pkey PRIMARY KEY (currency_id);


--
-- Name: customer customer_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customer
    ADD CONSTRAINT customer_pkey PRIMARY KEY (customer_id);


--
-- Name: email_template email_template_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.email_template
    ADD CONSTRAINT email_template_pkey PRIMARY KEY (template_id);


--
-- Name: invoice invoice_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.invoice
    ADD CONSTRAINT invoice_pkey PRIMARY KEY (invoice_id);


--
-- Name: login_history login_history_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.login_history
    ADD CONSTRAINT login_history_pkey PRIMARY KEY (token_id);


--
-- Name: support-ticket support-ticket_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."support-ticket"
    ADD CONSTRAINT "support-ticket_pkey" PRIMARY KEY (ticket_id);


--
-- Name: transaction_master_nowpayments transaction_master_nowpayments_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.transaction_master_nowpayments
    ADD CONSTRAINT transaction_master_nowpayments_pkey PRIMARY KEY (tid);


--
-- Name: transaction transaction_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.transaction
    ADD CONSTRAINT transaction_pkey PRIMARY KEY (id);


--
-- Name: transactions-for deleted transactions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."transactions-for deleted"
    ADD CONSTRAINT transactions_pkey PRIMARY KEY (transactionid);


--
-- Name: wallet_list wallet_list_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.wallet_list
    ADD CONSTRAINT wallet_list_pkey PRIMARY KEY (wallet_id);


--
-- PostgreSQL database dump complete
--

